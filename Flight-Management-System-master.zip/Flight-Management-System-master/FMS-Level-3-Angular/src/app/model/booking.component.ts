export class Booking {

  bookingId: number;
  bookingDate: string;
  noOfPassengers: number;

}
